# fibonacci
#this is fibonaci script